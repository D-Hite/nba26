MODEL (
  name fantasy.weekly_breakouts,
  kind VIEW,
  dialect snowflake,
  description "Weekly breakouts: minutes delta vs pre-week baseline + weekly totalZWeek, with weekly stat context."
);

WITH current_season AS (
  SELECT seasonId
  FROM raw.current_season
),

ws AS (
  SELECT
    seasonId,
    personId,
    firstName,
    familyName,

    weekNumber,
    weekStartDate,
    weekEndDate,
    seasonWeekId,

    gamesPlayedWeek,

    -- weekly totals (context)
    pointsSum,
    assistsSum,
    reboundsSum,
    stealsSum,
    blocksSum,
    threesSum,
    doubleDoubleSum,

    -- weekly per-game avgs (optional context)
    minutesAvg,
    pointsAvg,
    assistsAvg,
    reboundsAvg,
    stealsAvg,
    blocksAvg,
    threesAvg,

    efgPctAvg,
    ftPctAvg,

    -- weekly z + total
    totalZWeek
  FROM fantasy.weekly_stats
  WHERE seasonId = (SELECT seasonId FROM current_season)
),

baseline AS (
  SELECT
    w.seasonId,
    w.personId,
    w.weekStartDate,
    a.average_minutes AS baseline_minutes
  FROM (
    SELECT DISTINCT seasonId, personId, weekStartDate
    FROM ws
  ) w
  LEFT JOIN fantasy.averages a
    ON a.seasonId = w.seasonId
   AND a.personId = w.personId
   AND CAST(a.gameDate AS DATE) < CAST(w.weekStartDate AS DATE)
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY w.seasonId, w.personId, w.weekStartDate
    ORDER BY CAST(a.gameDate AS DATE) DESC
  ) = 1
),

joined AS (
  SELECT
    ws.*,
    b.baseline_minutes,
    (ws.minutesAvg - b.baseline_minutes) AS minutes_delta_week
  FROM ws
  LEFT JOIN baseline b
    ON ws.seasonId = b.seasonId
   AND ws.personId = b.personId
   AND ws.weekStartDate = b.weekStartDate
),

scored AS (
  SELECT
    j.*,

    /* combo score: role + impact */
    (0.60 * COALESCE(minutes_delta_week, 0))
    + (0.40 * COALESCE(totalZWeek, 0)) AS breakoutScore,

    (
      (
        (0.60 * COALESCE(minutes_delta_week, 0))
        + (0.40 * COALESCE(totalZWeek, 0))
      )
      - AVG(
          (0.60 * COALESCE(minutes_delta_week, 0))
          + (0.40 * COALESCE(totalZWeek, 0))
        ) OVER (PARTITION BY seasonId, weekStartDate)
    )
    / NULLIF(
        STDDEV(
          (0.60 * COALESCE(minutes_delta_week, 0))
          + (0.40 * COALESCE(totalZWeek, 0))
        ) OVER (PARTITION BY seasonId, weekStartDate),
        0
      ) AS breakoutZScoreWeek
  FROM joined j
)

SELECT
  *,
  CASE
    WHEN gamesPlayedWeek >= 2
     AND baseline_minutes IS NOT NULL
     AND minutes_delta_week >= 4
     AND breakoutZScoreWeek >= 1.0
    THEN 1 ELSE 0
  END AS isBreakout
FROM scored;
