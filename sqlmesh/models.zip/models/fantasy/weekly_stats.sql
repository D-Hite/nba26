MODEL (
  name fantasy.weekly_stats,
  kind VIEW,
  dialect snowflake
);

WITH base AS (
    SELECT
        bs.*
    FROM fantasy.base_stats bs
    WHERE bs.seasonId = (
        SELECT seasonId
        FROM raw.current_season
    )
),

withWeeks AS (
    SELECT
        b.*,
        DATEADD(day, 1 - DAYOFWEEKISO(b.gameDate), b.gameDate) AS weekStartDate,
        DATEADD(day, 7 - DAYOFWEEKISO(b.gameDate), b.gameDate) AS weekEndDate
    FROM base b
),

weeklyAgg AS (
    SELECT
        personId,
        firstName,
        familyName,
        seasonId,
        weekStartDate,
        weekEndDate,
        CONCAT(seasonId, '_', TO_CHAR(weekStartDate, 'IYYY-IW')) AS seasonWeekId,

        COUNT_IF(playedFlag = 1) AS gamesPlayedWeek,

        SUM(CASE WHEN playedFlag = 1 THEN minutes           END) AS minutesSum,
        SUM(CASE WHEN playedFlag = 1 THEN points            END) AS pointsSum,
        SUM(CASE WHEN playedFlag = 1 THEN assists           END) AS assistsSum,
        SUM(CASE WHEN playedFlag = 1 THEN reboundsTotal     END) AS reboundsSum,
        SUM(CASE WHEN playedFlag = 1 THEN steals            END) AS stealsSum,
        SUM(CASE WHEN playedFlag = 1 THEN blocks            END) AS blocksSum,
        SUM(CASE WHEN playedFlag = 1 THEN threePointersMade END) AS threesSum,
        SUM(CASE WHEN playedFlag = 1 THEN doubleDouble      END) AS doubleDoubleSum,

        AVG(CASE WHEN playedFlag = 1 THEN minutes           END) AS minutesAvg,
        AVG(CASE WHEN playedFlag = 1 THEN points            END) AS pointsAvg,
        AVG(CASE WHEN playedFlag = 1 THEN assists           END) AS assistsAvg,
        AVG(CASE WHEN playedFlag = 1 THEN reboundsTotal     END) AS reboundsAvg,
        AVG(CASE WHEN playedFlag = 1 THEN steals            END) AS stealsAvg,
        AVG(CASE WHEN playedFlag = 1 THEN blocks            END) AS blocksAvg,
        AVG(CASE WHEN playedFlag = 1 THEN threePointersMade END) AS threesAvg,

        AVG(CASE WHEN playedFlag = 1 THEN effectiveFieldGoalPercentage END) AS efgPctAvg,
        AVG(CASE WHEN playedFlag = 1 THEN freeThrowsPercentage         END) AS ftPctAvg
    FROM withWeeks
    GROUP BY
        personId, firstName, familyName,
        seasonId, weekStartDate, weekEndDate
),

-- ✅ one row per season/week, then number the weeks
week_index AS (
    SELECT
        seasonId,
        weekStartDate,
        DENSE_RANK() OVER (
            PARTITION BY seasonId
            ORDER BY weekStartDate
        ) AS weekNumber
    FROM (
        SELECT DISTINCT seasonId, weekStartDate
        FROM weeklyAgg
    )
),

weeklyZ AS (
    SELECT
        wa.*,
        wi.weekNumber,

        (pointsSum  - AVG(pointsSum)  OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(pointsSum)   OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS pointsZScoreWeek,

        (assistsSum - AVG(assistsSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(assistsSum)  OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS assistsZScoreWeek,

        (reboundsSum - AVG(reboundsSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(reboundsSum)   OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS reboundsZScoreWeek,

        (stealsSum - AVG(stealsSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(stealsSum)  OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS stealsZScoreWeek,

        (blocksSum - AVG(blocksSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(blocksSum)  OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS blocksZScoreWeek,

        (threesSum - AVG(threesSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(threesSum)  OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS threesZScoreWeek,

        (doubleDoubleSum - AVG(doubleDoubleSum) OVER (PARTITION BY wa.seasonId, wa.weekStartDate))
        / NULLIF(STDDEV(doubleDoubleSum)        OVER (PARTITION BY wa.seasonId, wa.weekStartDate), 0)
            AS doubleDoubleZScoreWeek
    FROM weeklyAgg wa
    JOIN week_index wi
      ON wa.seasonId = wi.seasonId
     AND wa.weekStartDate = wi.weekStartDate
)

SELECT
    *,
    pointsZScoreWeek +
    assistsZScoreWeek +
    reboundsZScoreWeek +
    stealsZScoreWeek +
    blocksZScoreWeek +
    threesZScoreWeek +
    doubleDoubleZScoreWeek AS totalZWeek
FROM weeklyZ;
